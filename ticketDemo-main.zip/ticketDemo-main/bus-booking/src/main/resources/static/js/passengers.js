document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const loadingSpinner = document.getElementById('loadingSpinner');
    const errorAlert = document.getElementById('errorAlert');
    const noPassengersAlert = document.getElementById('noPassengersAlert');
    const passengersTableContainer = document.getElementById('passengersTableContainer');
    const passengersTableBody = document.getElementById('passengersTableBody');
    const searchInput = document.getElementById('searchInput');
    
    // State variables
    let passengers = [];
    let filteredPassengers = [];
    
    // Fetch passengers data
    function fetchPassengers() {
        loadingSpinner.classList.remove('d-none');
        errorAlert.classList.add('d-none');
        noPassengersAlert.classList.add('d-none');
        passengersTableContainer.classList.add('d-none');
        
        fetch('/api/passengers')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch passengers data');
                }
                return response.json();
            })
            .then(data => {
                passengers = data;
                filteredPassengers = [...passengers];
                renderPassengers();
                loadingSpinner.classList.add('d-none');
            })
            .catch(error => {
                console.error('Error fetching passengers:', error);
                loadingSpinner.classList.add('d-none');
                errorAlert.classList.remove('d-none');
            });
    }
    
    // Render passengers in the table
    function renderPassengers() {
        // Clear existing rows
        passengersTableBody.innerHTML = '';
        
        if (filteredPassengers.length === 0) {
            noPassengersAlert.classList.remove('d-none');
            passengersTableContainer.classList.add('d-none');
            return;
        }
        
        // Add rows for each passenger
        filteredPassengers.forEach(passenger => {
            const row = document.createElement('tr');
            
            // Name cell
            const nameCell = document.createElement('td');
            nameCell.textContent = `${passenger.firstName} ${passenger.lastName}`;
            row.appendChild(nameCell);
            
            // Email cell
            const emailCell = document.createElement('td');
            emailCell.textContent = passenger.email;
            row.appendChild(emailCell);
            
            // Phone number cell
            const phoneCell = document.createElement('td');
            phoneCell.textContent = passenger.phoneNumber;
            row.appendChild(phoneCell);
            
            // ID proof type cell
            const idProofTypeCell = document.createElement('td');
            idProofTypeCell.textContent = passenger.idProofType;
            row.appendChild(idProofTypeCell);
            
            // Actions cell
            const actionsCell = document.createElement('td');
            
            // View button
            const viewBtn = document.createElement('a');
            viewBtn.href = `passenger-profile.html?id=${passenger.id}`;
            viewBtn.className = 'btn btn-sm btn-info me-2';
            viewBtn.textContent = 'View';
            actionsCell.appendChild(viewBtn);
            
            // Edit button
            const editBtn = document.createElement('a');
            editBtn.href = `passenger-profile.html?id=${passenger.id}&edit=true`;
            editBtn.className = 'btn btn-sm btn-primary';
            editBtn.textContent = 'Edit';
            actionsCell.appendChild(editBtn);
            
            row.appendChild(actionsCell);
            
            // Add row to table
            passengersTableBody.appendChild(row);
        });
        
        // Show table
        passengersTableContainer.classList.remove('d-none');
        noPassengersAlert.classList.add('d-none');
    }
    
    // Filter passengers based on search term
    function filterPassengers(searchTerm) {
        if (!searchTerm.trim()) {
            filteredPassengers = [...passengers];
        } else {
            const term = searchTerm.toLowerCase();
            filteredPassengers = passengers.filter(passenger => 
                passenger.firstName.toLowerCase().includes(term) ||
                passenger.lastName.toLowerCase().includes(term) ||
                passenger.email.toLowerCase().includes(term) ||
                passenger.phoneNumber.includes(term)
            );
        }
        
        renderPassengers();
    }
    
    // Handle search input
    searchInput.addEventListener('input', function() {
        filterPassengers(this.value);
    });
    
    // Initialize page
    fetchPassengers();
}); 