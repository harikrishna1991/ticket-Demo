document.addEventListener('DOMContentLoaded', function() {
    // Get URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const passengerId = urlParams.get('id');
    
    // DOM elements
    const viewMode = document.getElementById('viewMode');
    const editForm = document.getElementById('editForm');
    const editBtn = document.getElementById('editBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    const deleteBtn = document.getElementById('deleteBtn');
    const successAlert = document.getElementById('successAlert');
    const errorAlert = document.getElementById('errorAlert');
    
    // Form elements
    const firstNameInput = document.getElementById('firstName');
    const lastNameInput = document.getElementById('lastName');
    const emailInput = document.getElementById('email');
    const phoneNumberInput = document.getElementById('phoneNumber');
    const addressInput = document.getElementById('address');
    const idProofTypeInput = document.getElementById('idProofType');
    const idProofNumberInput = document.getElementById('idProofNumber');
    
    // View elements
    const viewFirstName = document.getElementById('viewFirstName');
    const viewLastName = document.getElementById('viewLastName');
    const viewEmail = document.getElementById('viewEmail');
    const viewPhoneNumber = document.getElementById('viewPhoneNumber');
    const viewAddress = document.getElementById('viewAddress');
    const viewIdProofType = document.getElementById('viewIdProofType');
    const viewIdProofNumber = document.getElementById('viewIdProofNumber');
    
    // Fetch passenger data
    function fetchPassengerData() {
        if (!passengerId) {
            showError('Passenger ID is missing');
            return;
        }
        
        fetch(`/api/passengers/${passengerId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch passenger data');
                }
                return response.json();
            })
            .then(data => {
                // Populate view mode
                viewFirstName.textContent = data.firstName || '';
                viewLastName.textContent = data.lastName || '';
                viewEmail.textContent = data.email || '';
                viewPhoneNumber.textContent = data.phoneNumber || '';
                viewAddress.textContent = data.address || '';
                viewIdProofType.textContent = data.idProofType || '';
                viewIdProofNumber.textContent = data.idProofNumber || '';
                
                // Populate form fields
                firstNameInput.value = data.firstName || '';
                lastNameInput.value = data.lastName || '';
                emailInput.value = data.email || '';
                phoneNumberInput.value = data.phoneNumber || '';
                addressInput.value = data.address || '';
                idProofTypeInput.value = data.idProofType || '';
                idProofNumberInput.value = data.idProofNumber || '';
            })
            .catch(error => {
                console.error('Error fetching passenger data:', error);
                showError('Failed to load passenger data');
            });
    }
    
    // Show error message
    function showError(message) {
        errorAlert.textContent = message;
        errorAlert.classList.remove('d-none');
        setTimeout(() => {
            errorAlert.classList.add('d-none');
        }, 5000);
    }
    
    // Show success message
    function showSuccess(message) {
        successAlert.textContent = message;
        successAlert.classList.remove('d-none');
        setTimeout(() => {
            successAlert.classList.add('d-none');
        }, 3000);
    }
    
    // Toggle between view and edit modes
    function toggleEditMode() {
        viewMode.classList.toggle('d-none');
        editForm.classList.toggle('d-none');
    }
    
    // Handle edit button click
    editBtn.addEventListener('click', function() {
        toggleEditMode();
    });
    
    // Handle cancel button click
    cancelBtn.addEventListener('click', function() {
        toggleEditMode();
    });
    
    // Handle form submission
    editForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!editForm.checkValidity()) {
            e.stopPropagation();
            editForm.classList.add('was-validated');
            return;
        }
        
        // Prepare data for submission
        const passengerData = {
            firstName: firstNameInput.value,
            lastName: lastNameInput.value,
            email: emailInput.value,
            phoneNumber: phoneNumberInput.value,
            address: addressInput.value,
            idProofType: idProofTypeInput.value,
            idProofNumber: idProofNumberInput.value
        };
        
        // Submit data to server
        fetch(`/api/passengers/${passengerId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(passengerData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to update passenger data');
            }
            return response.json();
        })
        .then(data => {
            // Update view mode with new data
            viewFirstName.textContent = data.firstName || '';
            viewLastName.textContent = data.lastName || '';
            viewEmail.textContent = data.email || '';
            viewPhoneNumber.textContent = data.phoneNumber || '';
            viewAddress.textContent = data.address || '';
            viewIdProofType.textContent = data.idProofType || '';
            viewIdProofNumber.textContent = data.idProofNumber || '';
            
            // Switch back to view mode
            toggleEditMode();
            
            // Show success message
            showSuccess('Profile updated successfully!');
        })
        .catch(error => {
            console.error('Error updating passenger data:', error);
            showError('Failed to update passenger data');
        });
    });
    
    // Handle delete button click
    deleteBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to delete this passenger profile? This action cannot be undone.')) {
            fetch(`/api/passengers/${passengerId}`, {
                method: 'DELETE'
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to delete passenger data');
                }
                // Redirect to passengers list
                window.location.href = 'passengers.html';
            })
            .catch(error => {
                console.error('Error deleting passenger data:', error);
                showError('Failed to delete passenger data');
            });
        }
    });
    
    // Initialize page
    fetchPassengerData();
}); 