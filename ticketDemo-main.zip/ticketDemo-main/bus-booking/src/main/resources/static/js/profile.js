/**
 * User Profile JavaScript - Handles user profile functionality
 * - Loads and displays user information
 * - Updates personal information
 * - Changes password
 * - Manages payment methods
 */

// Global variables
let userId = null;
let userInfo = null;
let paymentMethods = [];

// Initialize the page when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Profile page initialized');
    
    // Check if user is authenticated
    if (!isAuthenticated()) {
        window.location.href = '/login';
        return;
    }
    
    // Load user profile data
    loadUserProfile();
    
    // Initialize event listeners
    initializeEventListeners();
});

// Check if user is authenticated
function isAuthenticated() {
    // Use the same authentication check as auth.js
    const token = localStorage.getItem('authToken');
    if (!token) {
        return false;
    }
    
    try {
        const user = JSON.parse(localStorage.getItem('user'));
        return user && user.username;
    } catch (e) {
        console.error('Error checking authentication:', e);
        return false;
    }
}

// Initialize all event listeners
function initializeEventListeners() {
    // Personal information form
    const personalInfoForm = document.getElementById('personalInfoForm');
    if (personalInfoForm) {
        personalInfoForm.addEventListener('submit', function(e) {
            e.preventDefault();
            updatePersonalInfo();
        });
    }
    
    // Password form
    const passwordForm = document.getElementById('passwordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            changePassword();
        });
    }
    
    // Password validation
    const newPasswordField = document.getElementById('newPassword');
    const confirmPasswordField = document.getElementById('confirmPassword');
    
    if (newPasswordField && confirmPasswordField) {
        newPasswordField.addEventListener('input', function() {
            validatePasswordMatch(newPasswordField, confirmPasswordField);
            updatePasswordStrength(newPasswordField.value);
        });
        
        confirmPasswordField.addEventListener('input', function() {
            validatePasswordMatch(newPasswordField, confirmPasswordField);
        });
    }
    
    // Payment method form
    const paymentMethodForm = document.getElementById('paymentMethodForm');
    if (paymentMethodForm) {
        // Card number formatting
        const cardNumberField = document.getElementById('cardNumber');
        if (cardNumberField) {
            cardNumberField.addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                let formattedValue = '';
                for (let i = 0; i < value.length; i++) {
                    if (i > 0 && i % 4 === 0) {
                        formattedValue += ' ';
                    }
                    formattedValue += value[i];
                }
                e.target.value = formattedValue;
            });
        }
    }
}

// Load user profile information from API
function loadUserProfile() {
    // Get auth token from localStorage
    const token = localStorage.getItem('authToken');
    
    fetch('/api/users/profile', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('Failed to load profile');
        }
        return response.json();
    })
    .then(data => {
        console.log('Profile data loaded:', data);
        userInfo = data;
        userId = data.id;
        
        // Update personal information
        document.getElementById('firstName').value = data.name.split(' ')[0] || '';
        document.getElementById('lastName').value = data.name.split(' ').slice(1).join(' ') || '';
        document.getElementById('email').value = data.email || '';
        document.getElementById('phone').value = data.phone || '';
        
        // Update profile header
        const profileName = document.querySelector('.profile-header h2');
        if (profileName) {
            profileName.textContent = data.name || 'User';
        }
        
        const profileEmail = document.querySelector('.profile-header p');
        if (profileEmail) {
            profileEmail.textContent = data.email || '';
        }
        
        // Load payment methods
        loadPaymentMethods();
    })
    .catch(error => {
        console.error('Error loading profile:', error);
        showError('Failed to load profile data: ' + error.message);
    });
}

// Update personal information
function updatePersonalInfo() {
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    
    // Validate form data
    const errors = validateForm({
        firstName: firstName,
        lastName: lastName,
        email: email,
        phone: phone
    });
    
    if (errors.length > 0) {
        showError(errors.join('<br>'));
        return;
    }
    
    // Get auth token from localStorage
    const token = localStorage.getItem('authToken');
    
    // Create request payload
    const formData = {
        name: `${firstName} ${lastName}`.trim(),
        email: email,
        phone: phone
    };
    
    // Disable submit button
    const submitBtn = document.querySelector('#personalInfoForm button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...';
    }
    
    // Make API request
    fetch('/api/users/profile', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        body: JSON.stringify(formData),
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('Failed to update profile');
        }
        return response.json();
    })
    .then(data => {
        showSuccess('Profile updated successfully');
        loadUserProfile(); // Reload profile data
    })
    .catch(error => {
        console.error('Error updating profile:', error);
        showError('Failed to update profile: ' + error.message);
    })
    .finally(() => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>Save Changes';
        }
    });
}

// Validate form data
function validateForm(formData) {
    const errors = [];
    
    // Personal Info Validation
    if (formData.firstName && (formData.firstName.length < 2 || formData.firstName.length > 50)) {
        errors.push('First name must be between 2 and 50 characters');
    }
    
    if (formData.lastName && (formData.lastName.length < 2 || formData.lastName.length > 50)) {
        errors.push('Last name must be between 2 and 50 characters');
    }
    
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        errors.push('Please enter a valid email address');
    }
    
    if (formData.phone && !/^\+?[\d\s-]{10,}$/.test(formData.phone)) {
        errors.push('Please enter a valid phone number');
    }
    
    return errors;
}

// Validate password
function validatePassword(password) {
    const errors = [];
    
    if (password.length < 8) {
        errors.push('Password must be at least 8 characters long');
    }
    
    if (!/[A-Z]/.test(password)) {
        errors.push('Password must contain at least one uppercase letter');
    }
    
    if (!/[a-z]/.test(password)) {
        errors.push('Password must contain at least one lowercase letter');
    }
    
    if (!/[0-9]/.test(password)) {
        errors.push('Password must contain at least one number');
    }
    
    if (!/[!@#$%^&*]/.test(password)) {
        errors.push('Password must contain at least one special character (!@#$%^&*)');
    }
    
    return errors;
}

// Update password strength indicator
function updatePasswordStrength(password) {
    const strengthBar = document.querySelector('.password-strength');
    const requirements = document.querySelectorAll('.requirement-item');
    
    if (!strengthBar || !requirements.length) return;
    
    // Reset all requirements
    requirements.forEach(req => {
        req.classList.remove('requirement-met');
        req.classList.add('requirement-unmet');
        req.querySelector('i').className = 'fas fa-circle';
    });
    
    // Check length requirement
    if (password.length >= 8) {
        requirements[0].classList.remove('requirement-unmet');
        requirements[0].classList.add('requirement-met');
        requirements[0].querySelector('i').className = 'fas fa-check-circle';
    }
    
    // Check uppercase requirement
    if (/[A-Z]/.test(password)) {
        requirements[1].classList.remove('requirement-unmet');
        requirements[1].classList.add('requirement-met');
        requirements[1].querySelector('i').className = 'fas fa-check-circle';
    }
    
    // Check lowercase requirement
    if (/[a-z]/.test(password)) {
        requirements[2].classList.remove('requirement-unmet');
        requirements[2].classList.add('requirement-met');
        requirements[2].querySelector('i').className = 'fas fa-check-circle';
    }
    
    // Check number requirement
    if (/[0-9]/.test(password)) {
        requirements[3].classList.remove('requirement-unmet');
        requirements[3].classList.add('requirement-met');
        requirements[3].querySelector('i').className = 'fas fa-check-circle';
    }
    
    // Check special character requirement
    if (/[!@#$%^&*]/.test(password)) {
        requirements[4].classList.remove('requirement-unmet');
        requirements[4].classList.add('requirement-met');
        requirements[4].querySelector('i').className = 'fas fa-check-circle';
    }
    
    // Calculate overall strength
    let strength = 0;
    requirements.forEach(req => {
        if (req.classList.contains('requirement-met')) {
            strength += 20;
        }
    });
    
    // Update strength bar
    strengthBar.style.width = strength + '%';
    
    if (strength <= 20) {
        strengthBar.style.backgroundColor = '#dc3545'; // Red
    } else if (strength <= 40) {
        strengthBar.style.backgroundColor = '#ffc107'; // Yellow
    } else if (strength <= 60) {
        strengthBar.style.backgroundColor = '#fd7e14'; // Orange
    } else if (strength <= 80) {
        strengthBar.style.backgroundColor = '#0dcaf0'; // Light blue
    } else {
        strengthBar.style.backgroundColor = '#198754'; // Green
    }
}

// Validate password fields match
function validatePasswordMatch(passwordField, confirmField) {
    const password = passwordField.value;
    const confirmPassword = confirmField.value;
    
    if (confirmPassword && password !== confirmPassword) {
        confirmField.classList.add('is-invalid');
        return false;
    } else {
        confirmField.classList.remove('is-invalid');
        return true;
    }
}

// Change password
function changePassword() {
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Validate password fields
    if (!currentPassword || !newPassword || !confirmPassword) {
        showError('All password fields are required');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showError('New passwords do not match');
        return;
    }
    
    // Validate password strength
    const passwordErrors = validatePassword(newPassword);
    if (passwordErrors.length > 0) {
        showError(passwordErrors.join('<br>'));
        return;
    }
    
    // Get auth token from localStorage
    const token = localStorage.getItem('authToken');
    
    // Create request payload
    const passwordRequest = {
        currentPassword: currentPassword,
        newPassword: newPassword
    };
    
    // Disable submit button
    const submitBtn = document.querySelector('#passwordForm button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Changing...';
    }
    
    // Make API request
    fetch('/api/users/change-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        body: JSON.stringify(passwordRequest),
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('Failed to change password');
        }
        return response.json();
    })
    .then(data => {
        showSuccess('Password changed successfully');
        document.getElementById('passwordForm').reset();
    })
    .catch(error => {
        console.error('Error changing password:', error);
        showError('Failed to change password: ' + error.message);
    })
    .finally(() => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-key me-2"></i>Change Password';
        }
    });
}

// Load payment methods
function loadPaymentMethods() {
    // Get auth token from localStorage
    const token = localStorage.getItem('authToken');
    
    fetch('/api/payment-methods', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('Failed to load payment methods');
        }
        return response.json();
    })
    .then(data => {
        console.log('Payment methods loaded:', data);
        paymentMethods = data;
        
        const paymentMethodsList = document.getElementById('paymentMethodsList');
        if (!paymentMethodsList) return;
        
        // Clear container
        paymentMethodsList.innerHTML = '';
        
        if (!data || data.length === 0) {
            paymentMethodsList.innerHTML = `
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    You don't have any payment methods yet. Add a payment method to make checkout faster.
                </div>
            `;
            return;
        }
        
        // Loop through methods and create cards
        data.forEach(method => {
            const methodCard = document.createElement('div');
            methodCard.className = 'payment-method-card';
            if (method.isDefault) {
                methodCard.classList.add('border-primary');
            }
            
            let cardIcon = 'fa-credit-card';
            if (method.type) {
                const cardType = method.type.toLowerCase();
                if (cardType.includes('visa')) {
                    cardIcon = 'fa-cc-visa';
                } else if (cardType.includes('mastercard')) {
                    cardIcon = 'fa-cc-mastercard';
                } else if (cardType.includes('amex')) {
                    cardIcon = 'fa-cc-amex';
                } else if (cardType.includes('discover')) {
                    cardIcon = 'fa-cc-discover';
                }
            }
            
            methodCard.innerHTML = `
                <div class="d-flex align-items-center">
                    <div class="payment-method-icon">
                        <i class="fab ${cardIcon}"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">${method.type || 'Credit Card'}</h5>
                        <p class="mb-0">**** **** **** ${method.cardNumber || '****'}</p>
                        <p class="mb-0 text-muted small">Expires: ${method.expiryDate || 'MM/YY'}</p>
                        ${method.isDefault ? '<span class="badge bg-primary mt-1">Default</span>' : ''}
                    </div>
                </div>
                <div class="card-actions">
                    ${!method.isDefault ? `<button class="btn btn-sm btn-outline-primary me-2" onclick="setDefaultPaymentMethod(${method.id})">Set Default</button>` : ''}
                    <button class="btn btn-sm btn-outline-danger" onclick="deletePaymentMethod(${method.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            
            paymentMethodsList.appendChild(methodCard);
        });
    })
    .catch(error => {
        console.error('Error loading payment methods:', error);
        showError('Failed to load payment methods: ' + error.message);
    });
}

// Add payment method
function addPaymentMethod() {
    const cardholderName = document.getElementById('cardholderName').value.trim();
    const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g, '');
    const expiryMonth = document.getElementById('expiryMonth').value;
    const expiryYear = document.getElementById('expiryYear').value;
    const cvv = document.getElementById('cvv').value.trim();
    
    // Validate all fields
    if (!cardholderName || !cardNumber || !expiryMonth || !expiryYear || !cvv) {
        showErrorInModal('All fields are required');
        return;
    }
    
    // Validate card number
    if (!validateCreditCard(cardNumber)) {
        showErrorInModal('Please enter a valid card number');
        return;
    }
    
    // Validate expiry date
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;
    
    if (parseInt(expiryYear) < currentYear || 
        (parseInt(expiryYear) === currentYear && parseInt(expiryMonth) < currentMonth)) {
        showErrorInModal('Card has expired');
        return;
    }
    
    // Validate CVV
    if (!/^\d{3,4}$/.test(cvv)) {
        showErrorInModal('CVV must be 3 or 4 digits');
        return;
    }
    
    // Get auth token from localStorage
    const token = localStorage.getItem('authToken');
    
    // Determine card type based on first digit
    let cardType = 'Unknown';
    const firstDigit = cardNumber.charAt(0);
    if (firstDigit === '4') {
        cardType = 'Visa';
    } else if (firstDigit === '5') {
        cardType = 'MasterCard';
    } else if (firstDigit === '3') {
        cardType = 'American Express';
    } else if (firstDigit === '6') {
        cardType = 'Discover';
    }
    
    // Create request payload
    const paymentMethodRequest = {
        cardholderName: cardholderName,
        cardNumber: cardNumber,
        expiryDate: `${expiryMonth}/${expiryYear}`,
        cvv: cvv,
        type: cardType
    };
    
    // Disable submit button
    const submitBtn = document.getElementById('savePaymentMethodBtn');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...';
    }
    
    // Make API request
    fetch('/api/payment-methods', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        body: JSON.stringify(paymentMethodRequest),
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('Failed to add payment method');
        }
        return response.json();
    })
    .then(data => {
        showSuccess('Payment method added successfully');
        document.getElementById('paymentMethodForm').reset();
        $('#addPaymentMethodModal').modal('hide');
        loadPaymentMethods();
    })
    .catch(error => {
        console.error('Error adding payment method:', error);
        showErrorInModal('Failed to add payment method: ' + error.message);
    })
    .finally(() => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>Save Payment Method';
        }
    });
}

// Validate credit card number using Luhn algorithm
function validateCreditCard(cardNumber) {
    // Remove spaces and dashes
    cardNumber = cardNumber.replace(/[\s-]/g, '');
    
    // Check if the card number contains only digits
    if (!/^\d+$/.test(cardNumber)) {
        return false;
    }
    
    // Luhn algorithm for card number validation
    let sum = 0;
    let isEven = false;
    
    for (let i = cardNumber.length - 1; i >= 0; i--) {
        let digit = parseInt(cardNumber[i]);
        
        if (isEven) {
            digit *= 2;
            if (digit > 9) {
                digit -= 9;
            }
        }
        
        sum += digit;
        isEven = !isEven;
    }
    
    return sum % 10 === 0;
}

// Set a payment method as default
function setDefaultPaymentMethod(methodId) {
    // Get auth token from localStorage
    const token = localStorage.getItem('authToken');
    
    fetch(`/api/payment-methods/${methodId}/default`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('Failed to set default payment method');
        }
        return response.json();
    })
    .then(data => {
        showSuccess('Default payment method updated');
        loadPaymentMethods();
    })
    .catch(error => {
        console.error('Error setting default payment method:', error);
        showError('Failed to set default payment method: ' + error.message);
    });
}

// Delete a payment method
function deletePaymentMethod(methodId) {
    if (!confirm('Are you sure you want to delete this payment method?')) {
        return;
    }
    
    // Get auth token from localStorage
    const token = localStorage.getItem('authToken');
    
    fetch(`/api/payment-methods/${methodId}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('Failed to delete payment method');
        }
        return response.json();
    })
    .then(data => {
        showSuccess('Payment method deleted successfully');
        loadPaymentMethods();
    })
    .catch(error => {
        console.error('Error deleting payment method:', error);
        showError('Failed to delete payment method: ' + error.message);
    });
}

// Show error message
function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    
    if (errorDiv && errorText) {
        errorText.innerHTML = message;
        errorDiv.style.display = 'block';
        
        // Hide after 5 seconds
        setTimeout(() => {
            errorDiv.style.display = 'none';
        }, 5000);
    }
}

// Show error message in modal
function showErrorInModal(message) {
    const errorDiv = document.getElementById('modalErrorMessage');
    
    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
        
        // Hide after 5 seconds
        setTimeout(() => {
            errorDiv.style.display = 'none';
        }, 5000);
    }
}

// Show success message
function showSuccess(message) {
    const successDiv = document.getElementById('successMessage');
    const successText = document.getElementById('successText');
    
    if (successDiv && successText) {
        successText.textContent = message;
        successDiv.style.display = 'block';
        
        // Hide after 5 seconds
        setTimeout(() => {
            successDiv.style.display = 'none';
        }, 5000);
    }
} 