package com.busbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
